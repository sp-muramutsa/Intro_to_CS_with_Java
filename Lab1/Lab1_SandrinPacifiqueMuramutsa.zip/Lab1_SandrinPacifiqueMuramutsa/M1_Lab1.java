/*
  Practicing working with the IDE and native datatypes
  Sandrin Pacifique Muramutsa
  01/15/2024
 */

public class M1_Lab1 {
    
    public static void main(String[] args) {
        
        System.out.println("\n\nExercise 1");
        System.out.print("\n\nHello World!\n\n");
        
        String firstName = "Sandrin Pacifique";
        String lastName = "Muramutsa";
        
        System.out.print("Hello, " + firstName + " " +lastName + "\n\n");
        
        int factor = 13;
        double rate = 4.5;
        char response='y';
        
        System.out.println(factor+ " is a factor of 39\n");      
        System.out.println("The interest rate on my house is "+rate);
        System.out.println("Your response was "+"'"+response+"'");
        System.out.println("Their response was \"Not in this lifetime\"");
        
        System.out.println("\n\nExercise 2"); 
        System.out.println("Name: Sandrin Pacifique Muramutsa"); 
        System.out.println("Major: Computer Science");    
        System.out.println("Class: Freshman\n");        
        
        System.out.println("Exercise 3");
        System.out.println("\"Moo !\" \"I love CSCI 281!\"");
        System.out.println(" ----------");
        System.out.println("       \\   ^  ^");
        System.out.println("        \\   ^__^");
        System.out.println("         \\  (oo)\\_______");
        System.out.println("            (__)\\       )\\/\\");
        System.out.println("                ||----w |");
        System.out.println("                ||     ||");
        System.out.println("                ||     ||");
        System.out.println("                ||     ||"); 
        System.out.println("                <=     <="); 
        System.out.println("\tDone by Sandrin\n"); 
               
    }
    
}
